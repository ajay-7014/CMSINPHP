<?php

	session_start();
	$con = mysqli_connect('localhost','root','','apperalabs_db');
	
	function check_merchant_session(){
		if($_SESSION['userData']['account_type']!=1){
			header("location:index.php");
		}
	}

	function check_affiliate_session(){
		if($_SESSION['userData']['account_type']!=0){
			header("location:index.php");
		}
	}

	function pr($val){
		echo "<pre>";
		print_r($val);
		echo "</pre>";
	}

	$recordPerPage = 5;
?>