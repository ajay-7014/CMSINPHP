<?php include("../config/settings.php");

if(isset($_SESSION['userInfo'])){	
	header("location:dashboard.php");
}else{
	header("location:login.php");
}
?>
