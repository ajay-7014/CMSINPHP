<?php include("../config/settings.php");?>
<?php 
	
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		// STATUS CHANGE		
		$stateData = mysqli_fetch_assoc(mysqli_query($con, "select * from services where id = $id"));
		$newStatus = ($stateData['status'] == 1)?0:1;
		$statusText = ($stateData['status'] == 1)?"Deactivated":"Activated";
		mysqli_query($con, "update services set status=$newStatus, modified=now() where id = $id");
		$_SESSION['flashMsg'] = "<div class='alert alert-success' role='alert'>Record $statusText successfully</div>";
	}
	if(isset($_GET['del_id'])){
		$id = $_GET['del_id'];
		// DELETE RECORD
		
		mysqli_query($con, "delete from services where id = $id");
		$_SESSION['flashMsg'] = "<div class='alert alert-success' role='alert'>Record deleted successfully</div>";		
	}	
	header("location:service.php");
?>