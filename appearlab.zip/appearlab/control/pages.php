<?php include("../config/settings.php");?>
<?php 
/* echo "<pre>";
print_r($_SESSION['userInfo']['first_name']);die; */
 	$per_page = 5;
$record =21;
$page = ceil($record/$per_page);
	

if((!isset($_SESSION['userInfo']))||(empty($_SESSION['userInfo']))){
	header("location:login.php");
}

?>


<?php

	$currentPageNo = (isset($_GET['page']))?$_GET['page']:1;
	$qry = mysqli_query($con, "select * from services");
	$totalRecords = mysqli_num_rows($qry);
	$TotalPages = $totalRecords/$recordPerPage;
	
	$startIndex = $recordPerPage*$currentPageNo-$recordPerPage;
	$qry = mysqli_query($con, "select * from services limit $startIndex,$recordPerPage");
	
	
	
	$flashMsg = "";
	if(isset($_SESSION['flashMsg'])){
		$flashMsg = $_SESSION['flashMsg'];
		unset($_SESSION['flashMsg']);
	}
?>



<?php /* $authError = "";
	if($_POST){
		//pr($_POST);die;
		$title = $_POST['title'];
		$slug = str_replace(" ","-",strtolower(trim($_POST['title'])));
		$slugPage = mysqli_fetch_assoc(mysqli_query($con, "select * from pages where slug = '$slug'"));
		if(!empty($slugPage)){
			$slug = $slug."-1";
		}
		$description = $_POST['description'];
		mysqli_query($con, "insert into pages set title='$title', slug='$slug', description='$description', created=now(), modified=now()");
		header("location:pages.php");
	} */

	$qry = mysqli_query($con, "select * from pages");
	$totalRecords = mysqli_num_rows($qry);
	
	$flashMsg = "";
	if(isset($_SESSION['flashMsg'])){
		$flashMsg = $_SESSION['flashMsg'];
		unset($_SESSION['flashMsg']);
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("includes/sidebar.php");?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->                
				<?php include("includes/topbar.php");?>
				<!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

					<div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Pages</h1>
                        <a href="create_page.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-plus fa-sm text-white-50"></i> Create new page</a>
                    </div>
                    <!-- Page Heading -->
                   <p class="mb-4">All pages listed below
                       <!--  For more information about DataTables, please visit the <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>-->
					<?php echo $flashMsg;?>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Title</th>
                                            <th>slug</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <!--<tr>
                                            <th>Name</th>
                                            <th>Position</th>
                                            <th>Office</th>
                                            <th>Age</th>
                                            <th>Start date</th>
                                        </tr>-->
                                    </tfoot>
                                    <tbody>
									
										<?php 
										$SNO = 1;
										if($totalRecords>0){
										while($res = mysqli_fetch_assoc($qry)){ ?>
                                        <tr>
                                            <td><?php echo $SNO;?></td>
                                            <td><?php echo $res['title'];?></td>
                                            <td><?php echo $res['slug'];?></td>
                                            <td>
											<?php echo ($res['status']=='1')?"<a class='btn btn-success btn-sm'>Active</a>":"<a class='btn btn-danger btn-sm'>Inactive</a>";?>
											</td>
                                            <td>
												<a href="edit_page.php?id=<?php echo $res['id'];?>" class="btn btn-success btn-sm">Edit</a>
												<a href="page_action.php?id=<?php echo $res['id'];?>" class="btn btn-warning btn-sm">Inativate</a>
												<a href="page_action.php?del_id=<?php echo $res['id'];?>" onclick="return confirm('Are you sure to delete it?');" class="btn btn-danger btn-sm">Delete</a>
											</td>
                                        </tr>
										<?php $SNO++;}?>
										<?php }else{?>
                                        <tr>
                                            <td colspan="5">No records available</td>
										</tr>
										<?php }?>
                                    </tbody>
                                </table>
								<nav aria-label="Page navigation example">
									  <ul class="pagination">
										<li class="page-item"><a class="page-link" href="<?php echo ($currentPageNo>1)?"?page=".($currentPageNo-1):"#";?>">Previous</a></li>
										<?php for($i=1; $i<=$TotalPages; $i++){?>
										<li class="page-item"><a class="page-link" href="?page=<?php echo $i;?>"><?php echo $i;?></a></li>
										<?php }?>
										<li class="page-item"><a class="page-link" href="<?php echo ($currentPageNo<$TotalPages)?"?page".($currentPageNo+1):"#";?> "onclick="return confirm('records no available here ?');" class="btn btn-danger btn-sm">Next</a></li>
										
										
									  </ul>
									</nav>
								
								
                            </div>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
			<?php include("includes/footer.php");?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>