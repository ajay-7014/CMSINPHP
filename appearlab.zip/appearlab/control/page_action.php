<?php include("../config/settings.php");?>
<?php 
	
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		// STATUS CHANGE		
		$pageData = mysqli_fetch_assoc(mysqli_query($con, "select * from pages where id = $id"));
		$newStatus = ($pageData['status'] == 1)?0:1;
		$statusText = ($pageData['status'] == 1)?"Deactivated":"Activated";
		mysqli_query($con, "update pages set status=$newStatus, modified=now() where id = $id");
		$_SESSION['flashMsg'] = "<div class='alert alert-success' role='alert'>Record $statusText successfully</div>";
	}
	if(isset($_GET['del_id'])){
		$id = $_GET['del_id'];
		// DELETE RECORD
		
		mysqli_query($con, "delete from pages where id = $id");
		$_SESSION['flashMsg'] = "<div class='alert alert-success' role='alert'>Record deleted successfully</div>";		
	}	
	header("location:pages.php");
?>