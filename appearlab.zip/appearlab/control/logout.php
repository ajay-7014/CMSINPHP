<?php include("../config/setting.php");?>
<?php 
	unset($_SESSION['userInfo']);
	header("location:login.php");
?>